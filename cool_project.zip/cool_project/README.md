## Cool Project

### Description

my cool new project

### Features

 - $(Project Feature 01)
 - $(Project Feature 02)
 - $(Project Feature 03)

### Controls

Keyboard/Mouse:
 - $(project Control 01)
 - $(project Control 02)
 - $(project Control 03)

### Screenshots

_TODO: Show your game to the world, animated GIFs recommended!._

### Developers

 - $(Developer 01) - $(Role/Tasks Developed)
 - $(Developer 02) - $(Role/Tasks Developed)
 - $(Developer 03) - $(Role/Tasks Developed)

### Links

 - YouTube Gameplay: $(YouTube Link)
 - itch.io Release: $(itch.io Game Page)
 - Steam Release: $(Steam Game Page)

### License

This project sources are licensed under an unmodified zlib/libpng license, which is an OSI-certified, BSD-like license that allows static linking with closed source software. Check [LICENSE](LICENSE) for further details.

$(Additional Licenses)

*Copyright (c) 2024 raylibtech ($(User Twitter/GitHub Name))*
